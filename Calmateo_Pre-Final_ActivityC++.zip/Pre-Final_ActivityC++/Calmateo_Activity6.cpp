// File:Calmaateo_Activity04.cpp
// Author: Calmateo MarkJomar S.
// Date: March 29, 2023
// Course: BSIT - 1A
// Program: Basic Calculator

#include <iostream>

using namespace std;

// function declarations
int sum(int num1, int num2);
int difference(int num1, int num2);
int product(int num1, int num2);
int quotient(int num1, int num2);

int main() {
int num1, num2;
int choice;

// get input from user
cout << "Enter two integers: ";
cin >> num1 >> num2;

// display menu
cout << "\nChoose Below to compute:" << endl;
cout << "1. Sum" << endl;
cout << "2. Difference" << endl;
cout << "3. Product" << endl;
cout << "4. Quotient" << endl;
cout << "Enter your choice 1-4 only:  ";
cin >> choice;

// perform computation based on user choice
switch(choice) {
    case 1:
        cout << "Sum of " << num1 << " and " << num2 << " is: " << sum(num1, num2) << endl;
        break;
    case 2:
        cout << "Difference of " << num1 << " and " << num2 << " is: " << difference(num1, num2) << endl;
        break;
    case 3:
        cout << "Product of " << num1 << " and " << num2 << " is: " << product(num1, num2) << endl;
        break;
    case 4:
        cout << "Quotient of " << num1 << " and " << num2 << " is: " << quotient(num1, num2) << endl;
        break;
    default:
        cout << "Invalid..." << endl;
}

return 0;
}

// function definitions
int sum(int num1, int num2) {
return num1 + num2;
}

int difference(int num1, int num2) {
return num1 - num2;
}

int product(int num1, int num2) {
return num1 * num2;
}

int quotient(int num1, int num2) {
return num1 / num2;
}