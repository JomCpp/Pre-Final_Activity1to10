// File:Calmaateo_Activity04.cpp
// Author: Calmateo MarkJomar S.
// Date: March 29, 2023
// Course: BSIT - 1A
// Program: Quotient of Two Integers

#include <iostream>

using namespace std;

// function declaration
int quotient(int n1, int n2);

int main() {
int n1, n2;

// get input from user
cout << "Enter two integers: ";
cin >> n1 >> n2;

// call function and output result
cout << "Quotient of " << n1 << " and " << n2 << " is: " << quotient(n1, n2) << endl;

return 0;
}

// function definition
int quotient(int n1, int n2) {
return n1 / n2;
}


) {
return num1 / num2;
}


