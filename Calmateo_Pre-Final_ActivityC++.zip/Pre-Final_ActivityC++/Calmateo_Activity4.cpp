// File:Calmaateo_Activity04.cpp
// Author: Calmateo MarkJomar S.
// Date: March 29, 2023
// Course: BSIT - 1A
// Program: Product of Two Integers

#include <iostream>

using namespace std;

// function declaration
int product(int n1, int n2);

int main() {
int n1, n2;

// get input from user
cout << "Enter two integers: ";
cin >> n1 >> n2;

// call function and output result
cout << "Product of " << n1 << " and " << n2 << " is: " << product(n1, n2) << endl;

return 0;
}

// function definition
int product(int n1, int n2) {
return n1 * n2;
}um2) {
return num1 * num2;
}