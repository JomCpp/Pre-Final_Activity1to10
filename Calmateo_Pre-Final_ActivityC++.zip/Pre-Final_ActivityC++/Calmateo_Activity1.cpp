// File:Calmaateo_Activity04.cpp
// Author: Calmateo MarkJomar S.
// Date: March 29, 2023
// Course: BSIT - 1A
//Function print 1st, lastname , course and year
#include <iostream>
using namespace std;

void prntnf(){
string lastName = "CALMATEO ";
string firstName = "MARK JOMAR ";
string middleName = "S. ";
string courseYear = "BS IN INFORMATION TECHNOLOGY";

cout << lastName << ", " << firstName << " " << middleName << " - " << courseYear << endl;
}

int main() 
{
    prntnf();
    return 0;
}