// File:Calmaateo_Activity04.cpp
// Author: Calmateo MarkJomar S.
// Date: March 29, 2023
// Course: BSIT - 1A
//PASS ARRAYS AS FUNCTION PARAMETERS

#include <iostream>
using namespace std;

void printArray(int arr[], int size) {
  for (int i = 0; i < size; i++) {
    cout << arr[i] << " ";
  }
  cout << endl;
}

int main() {
  int myNumbers[5] = {10, 20, 30, 40, 50};
  int size = sizeof(myNumbers) / sizeof(myNumbers[0]);
  printArray(myNumbers, size);
  return 0;
}
