// File:Calmaateo_Activity04.cpp
// Author: Calmateo MarkJomar S.
// Date: March 29, 2023
// Course: BSIT - 1A
//FUNCTION WITH PARAMETERS
#include <iostream>
#include <string>
using namespace std;

void prntnf(string lName, string fName, string mName, string crsYr){
    cout << lName << ", " << fName << " " << mName << " - " << crsYr << endl;
}

int main() 
{
    string lName = "Calmateo";
    string fName = "Mark Jomar";
    string mName = "S.";
    string crsYr = "BS in Information Technology";

    prntnf(lName, fName, mName, crsYr);

    return 0;
}
            e, firstName, middleName, courseYear);

    return 0;
}
            