// File:Calmaateo_Activity04.cpp
// Author: Calmateo MarkJomar S.
// Date: March 29, 2023
// Course: BSIT - 1A
//FUNCTION WITH PARAMETERS
#include <iostream>
#include <string>
using namespace std;

void prntnf(string lastName, string firstName, string middleName, string courseYear){
    cout << lastName << ", " << firstName << " " << middleName << " - " << courseYear << endl;
}

int main() 
{
    string lastName, firstName, middleName, courseYear;

    cout << "Please enter your last name: ";
    getline(cin, lastName);

    cout << "Please enter your first name: ";
    getline(cin, firstName);

    cout << "Please enter your middle name: ";
    getline(cin, middleName);

    cout << "Please enter your course and year: ";
    getline(cin, courseYear);

    prntnf(lastName, firstName, middleName, courseYear);

    return 0;
}
