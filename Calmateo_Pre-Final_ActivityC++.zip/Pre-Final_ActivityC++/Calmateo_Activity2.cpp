// File:Calmaateo_Activity04.cpp
// Author: Calmateo MarkJomar S.
// Date: March 29, 2023
// Course: BSIT - 1A
#include <iostream>
using namespace std;

int add(int n1, int n2){
return n1 + n2;
}

int main() {
int n1, n2;
cout << "Enter first number: ";
cin >> n1;
cout << "Enter second number: ";
cin >> n2;
cout << "Sum: " << add(n1, n2) << endl;
return 0;
}